(function() {
  var $, $$, $$$, Point, Range, View, deprecate, _ref, _ref1;

  _ref = require('text-buffer'), Point = _ref.Point, Range = _ref.Range;

  deprecate = require('grim').deprecate;

  module.exports = {
    BufferedNodeProcess: require('../src/buffered-node-process'),
    BufferedProcess: require('../src/buffered-process'),
    GitRepository: require('../src/git-repository'),
    Point: Point,
    Range: Range
  };

  if (!process.env.ATOM_SHELL_INTERNAL_RUN_AS_NODE) {
    _ref1 = require('../src/space-pen-extensions'), $ = _ref1.$, $$ = _ref1.$$, $$$ = _ref1.$$$, View = _ref1.View;
    module.exports.$ = $;
    module.exports.$$ = $$;
    module.exports.$$$ = $$$;
    module.exports.TextEditorView = require('../src/text-editor-view');
    module.exports.ScrollView = require('../src/scroll-view');
    module.exports.SelectListView = require('../src/select-list-view');
    module.exports.Task = require('../src/task');
    module.exports.View = View;
    module.exports.WorkspaceView = require('../src/workspace-view');
    module.exports.Workspace = require('../src/workspace');
    module.exports.React = require('react-atom-fork');
    module.exports.Reactionary = require('reactionary-atom-fork');
  }

  Object.defineProperty(module.exports, 'Git', {
    get: function() {
      deprecate("Please require `GitRepository` instead of `Git`: `{GitRepository} = require 'atom'`");
      return module.exports.GitRepository;
    }
  });

  Object.defineProperty(module.exports, 'EditorView', {
    get: function() {
      deprecate("Please require `TextEditorView` instead of `EditorView`: `{TextEditorView} = require 'atom'`");
      return module.exports.TextEditorView;
    }
  });

}).call(this);
